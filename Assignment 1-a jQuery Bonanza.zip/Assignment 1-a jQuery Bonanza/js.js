
    $('[href]').css("color" , "red");
    $('a[href="http//gmail.com"]').css("color" , "green");
    $(document).ready(function(){
        $('#btn1').click(function(){
            $('.para1').toggle();
        });
       $('input').focus(function(){
           $(this).css("background", "green")
       });
       $('input').blur(function(){
           $(this).css("background", "whit")
       });
       $('select#gender').change(function(){
            alert('change')
       });
   
       $('#newItem').keyup(function(e){
           var code = e.which;
           if(code == 13){
               e.preventDefault();
               $('ul').append('<li>'+ e .target .value +'</li>');
           };
       });
   
       $('#btnFadeOut').click (function(){
            $('#img1').fadeOut(3000)
       });
       $('#btnFadeIn').click (function(){
           $('#img1').fadeIn(3000)
      });
      $('#btnFadeToggle').click (function(){
       $('#img1').fadeToggle(4000)
   });
      $('#btnslidedown').click(function(){
          $('#img2').slideDown(3000);
      });
      $('#btnslideup').click(function(){
       $('#img2').slideUp(3000);
   });
      $('#btnslidetoggle').click(function(){
       $('#img2').slideToggle(3000);
   });
   $('#stop').click(function(){
       $('#img2').stop(3000);
   });
   $('#btnmoveRight').click(function(){
       $('#box3').animate({
           left: 500
           // opacity: '0.5',
       })
   });
   $('#btnmoveLeft').click(function(){
    $('#box3').animate({
               top: 0,
               left:0,
        })
      });
   $('#btnmovearound').click(function(){
    $('#box3').animate({
        left: 300,
      })
    });
    $('#btnmovearound').click(function(){
        $('#box3').animate({
            top: 300,
          })
        });
    $('#btnmovearound').click(function(){
        $('#box3').animate({
                top: 300,
                left:0,
          })
      });
     $('#btnmovearound').click(function(){
      $('#box3').animate({
                 top: 0,
                 left:0,
          })
        });

   $('#hidebtn1').click(function(){
    $("#para1").hide();
   });
   $('#showbtn1').click(function(){
    $("#para1").show();
   });
   $('#hidebtn2').click(function(){
    $("#para2").hide();
   });
   $('#showbtn2').click(function(){
    $("#para2").show();
   });
$('#btn1').click(function(){
    $('.para3').css('color', 'red' );
});
$('#btn2').click(function(){
    $('.para3').css('color', 'green' );
});

 });

    